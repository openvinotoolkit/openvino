/**
 * The entrypoint for the action.
 */
const { restore } = require('./restoreImpl');

restore();
