const { cleanUp } = require('./cleanupImpl');

cleanUp();
