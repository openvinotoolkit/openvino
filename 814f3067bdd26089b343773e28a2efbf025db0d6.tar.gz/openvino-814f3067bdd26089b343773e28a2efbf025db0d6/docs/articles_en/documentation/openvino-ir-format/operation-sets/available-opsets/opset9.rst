.. {#openvino_docs_ops_opset9}

opset9
======


.. meta::
  :description: Explore the examples of operation instances expressed as IR
                XML snippets in the opset9 operation set, supported in OpenVINO™
                toolkit.

This specification document describes the ``opset9`` operation set supported in OpenVINO™.
Support for each particular operation from the list below depends on the capabilities of an inference plugin
and may vary among different hardware platforms and devices. Examples of operation instances are provided as IR xml
snippets. The semantics match corresponding OpenVINO operation classes declared in ``namespace opset9``.


Table of Contents
######################

* :doc:`Abs <../operation-specs/arithmetic/abs-1>`
* :doc:`Acos <../operation-specs/arithmetic/acos-1>`
* :doc:`Acosh <../operation-specs/arithmetic/acosh-3>`
* :doc:`AdaptiveAvgPool <../operation-specs/pooling/adaptive-avg-pool-8>`
* :doc:`AdaptiveMaxPool <../operation-specs/pooling/adaptive-max-pool-8>`
* :doc:`Add <../operation-specs/arithmetic/add-1>`
* :doc:`Asin <../operation-specs/arithmetic/asin-1>`
* :doc:`Asinh <../operation-specs/arithmetic/asinh-3>`
* :doc:`Assign <../operation-specs/infrastructure/assign-3>`
* :doc:`Atan <../operation-specs/arithmetic/atan-1>`
* :doc:`Atanh <../operation-specs/arithmetic/atanh-3>`
* :doc:`AvgPool <../operation-specs/pooling/avg-pool-1>`
* :doc:`BatchNormInference <../operation-specs/normalization/batch-norm-inference-5>`
* :doc:`BatchToSpace <../operation-specs/movement/batch-to-space-2>`
* :doc:`BinaryConvolution <../operation-specs/convolution/binary-convolution-1>`
* :doc:`Broadcast <../operation-specs/movement/broadcast-3>`
* :doc:`Bucketize <../operation-specs/condition/bucketize-3>`
* :doc:`CTCGreedyDecoder <../operation-specs/sequence/ctc-greedy-decoder-1>`
* :doc:`CTCGreedyDecoderSeqLen <../operation-specs/sequence/ctc-greedy-decoder-seq-len-6>`
* :doc:`CTCLoss <../operation-specs/sequence/ctc-loss-4>`
* :doc:`Ceiling <../operation-specs/arithmetic/ceiling-1>`
* :doc:`Clamp <../operation-specs/activation/clamp-1>`
* :doc:`Concat <../operation-specs/movement/concat-1>`
* :doc:`Constant <../operation-specs/infrastructure/constant-1>`
* :doc:`Convert <../operation-specs/type/convert-1>`
* :doc:`ConvertLike <../operation-specs/type/convert-like-1>`
* :doc:`Convolution <../operation-specs/convolution/convolution-1>`
* :doc:`ConvolutionBackpropData <../operation-specs/convolution/convolution-backprop-data-1>`
* :doc:`Cos <../operation-specs/arithmetic/cos-1>`
* :doc:`Cosh <../operation-specs/arithmetic/cosh-1>`
* :doc:`CumSum <../operation-specs/arithmetic/cumsum-3>`
* :doc:`DeformableConvolution <../operation-specs/convolution/deformable-convolution-8>`
* :doc:`DeformablePSROIPooling <../operation-specs/detection/deformable-psroi-pooling-1>`
* :doc:`DepthToSpace <../operation-specs/movement/depth-to-space-1>`
* :doc:`DetectionOutput <../operation-specs/detection/detectionoutput-8>`
* :doc:`DFT <../operation-specs/signals/dft-7>`
* :doc:`Divide <../operation-specs/arithmetic/divide-1>`
* :doc:`Einsum <../operation-specs/matrix/einsum-7>`
* :doc:`Elu <../operation-specs/activation/elu-1>`
* :doc:`EmbeddingBagOffsetsSum <../operation-specs/sparse/embedding-bag-offsets-sum-3>`
* :doc:`EmbeddingBagPackedSum <../operation-specs/sparse/embedding-bag-packed-sum-3>`
* :doc:`EmbeddingSegmentsSum <../operation-specs/sparse/embedding-segments-sum-3>`
* :doc:`Equal <../operation-specs/comparison/equal-1>`
* :doc:`Erf <../operation-specs/arithmetic/erf-1>`
* :doc:`Exp <../operation-specs/activation/exp-1>`
* :doc:`ExperimentalDetectronDetectionOutput_6 <../operation-specs/detection/experimental-detectron-detection-output-6>`
* :doc:`ExperimentalDetectronGenerateProposalsSingleImage_6 <../operation-specs/detection/experimental-detectron-generate-proposals-single-image-6>`
* :doc:`ExperimentalDetectronPriorGridGenerator_6 <../operation-specs/detection/experimental-detectron-prior-grid-generator-6>`
* :doc:`ExperimentalDetectronROIFeatureExtractor_6 <../operation-specs/detection/experimental-detectron-roi-feature-extractor-6>`
* :doc:`ExperimentalDetectronTopKROIs_6 <../operation-specs/sort/experimental-detectron-top-krois-6>`
* :doc:`ExtractImagePatches <../operation-specs/movement/extract-image-patches-3>`
* :doc:`Eye <../operation-specs/generation/eye-9>`
* :doc:`FakeQuantize <../operation-specs/quantization/fake-quantize-1>`
* :doc:`Floor <../operation-specs/arithmetic/floor-1>`
* :doc:`FloorMod <../operation-specs/arithmetic/floormod-1>`
* :doc:`Gather <../operation-specs/movement/gather-8>`
* :doc:`GatherElements <../operation-specs/movement/gather-elements-6>`
* :doc:`GatherND <../operation-specs/movement/gather-nd-8>`
* :doc:`GatherTree <../operation-specs/movement/gather-tree-1>`
* :doc:`Gelu <../operation-specs/activation/gelu-7>`
* :doc:`GenerateProposals <../operation-specs/detection/generate-proposals-9>`
* :doc:`Greater <../operation-specs/comparison/greater-1>`
* :doc:`GreaterEqual <../operation-specs/comparison/greater-equal-1>`
* :doc:`GridSample <../operation-specs/image/grid-sample-9>`
* :doc:`GRN <../operation-specs/normalization/grn-1>`
* :doc:`GroupConvolution <../operation-specs/convolution/group-convolution-1>`
* :doc:`GroupConvolutionBackpropData <../operation-specs/convolution/group-convolution-backprop-data-1>`
* :doc:`GRUCell <../operation-specs/sequence/gru-cell-3>`
* :doc:`GRUSequence <../operation-specs/sequence/gru-sequence-5>`
* :doc:`HardSigmoid <../operation-specs/activation/hard-sigmoid-1>`
* :doc:`HSigmoid <../operation-specs/activation/hsigmoid-5>`
* :doc:`HSwish <../operation-specs/activation/hswish-4>`
* :doc:`IDFT <../operation-specs/signals/idft-7>`
* :doc:`I420toBGR <../operation-specs/image/i420-to-bgr-8>`
* :doc:`I420toRGB <../operation-specs/image/i420-to-rgb-8>`
* :doc:`If <../operation-specs/condition/if-8>`
* :doc:`Interpolate <../operation-specs/image/interpolate-4>`
* :doc:`IRDFT <../operation-specs/signals/irdft-9>`
* :doc:`Less <../operation-specs/comparison/less-1>`
* :doc:`LessEqual <../operation-specs/comparison/lessequal-1>`
* :doc:`Log <../operation-specs/arithmetic/log-1>`
* :doc:`LogicalAnd <../operation-specs/logical/logical-and-1>`
* :doc:`LogicalNot <../operation-specs/logical/logical-not-1>`
* :doc:`LogicalOr <../operation-specs/logical/logical-or-1>`
* :doc:`LogicalXor <../operation-specs/logical/logical-xor-1>`
* :doc:`LogSoftmax <../operation-specs/activation/log-soft-max-5>`
* :doc:`Loop <../operation-specs/infrastructure/loop-5>`
* :doc:`LRN <../operation-specs/normalization/lrn-1>`
* :doc:`LSTMCell <../operation-specs/sequence/lstm-cell-1>`
* :doc:`LSTMSequence <../operation-specs/sequence/lstm-sequence-1>`
* :doc:`MatMul <../operation-specs/matrix/matmul-1>`
* :doc:`MatrixNMS <../operation-specs/sort/matrix-non-max-suppression-8>`
* :doc:`MaxPool <../operation-specs/pooling/max-pool-8>`
* :doc:`Maximum <../operation-specs/arithmetic/maximum-1>`
* :doc:`Minimum <../operation-specs/arithmetic/minimum-1>`
* :doc:`Mish <../operation-specs/activation/mish-4>`
* :doc:`Mod <../operation-specs/arithmetic/mod-1>`
* :doc:`MVN <../operation-specs/normalization/mvn-6>`
* :doc:`MulticlassNMS <../operation-specs/sort/multiclass-non-max-suppression-9>`
* :doc:`Multiply <../operation-specs/arithmetic/multiply-1>`
* :doc:`Negative <../operation-specs/arithmetic/negative-1>`
* :doc:`NonMaxSuppression <../operation-specs/sort/no-max-suppression-5>`
* :doc:`NonZero <../operation-specs/condition/nonzero-3>`
* :doc:`NormalizeL2 <../operation-specs/normalization/normalize-l2-1>`
* :doc:`NotEqual <../operation-specs/comparison/notequal-1>`
* :doc:`NV12toBGR <../operation-specs/image/nv12-to-bgr-8>`
* :doc:`NV12toRGB <../operation-specs/image/nv12-to-rgb-8>`
* :doc:`OneHot <../operation-specs/sequence/one-hot-1>`
* :doc:`Pad <../operation-specs/movement/pad-1>`
* :doc:`Parameter <../operation-specs/infrastructure/parameter-1>`
* :doc:`Power <../operation-specs/arithmetic/power-1>`
* :doc:`PReLU <../operation-specs/activation/prelu-1>`
* :doc:`PriorBoxClustered <../operation-specs/detection/prior-box-clustered-1>`
* :doc:`PriorBox <../operation-specs/detection/prior-box-8>`
* :doc:`Proposal <../operation-specs/detection/proposal-4>`
* :doc:`PSROIPooling <../operation-specs/detection/psroi-pooling-1>`
* :doc:`RandomUniform <../operation-specs/generation/random-uniform-8>`
* :doc:`Range <../operation-specs/generation/range-4>`
* :doc:`RDFT <../operation-specs/signals/rdft-9>`
* :doc:`ReLU <../operation-specs/activation/relu-1>`
* :doc:`ReadValue <../operation-specs/infrastructure/read-value-3>`
* :doc:`ReduceL1 <../operation-specs/reduction/reduce-l1-4>`
* :doc:`ReduceL2 <../operation-specs/reduction/reduce-l2-4>`
* :doc:`ReduceLogicalAnd <../operation-specs/reduction/reduce-logical-and-1>`
* :doc:`ReduceLogicalOr <../operation-specs/reduction/reduce-logical-or-1>`
* :doc:`ReduceMax <../operation-specs/reduction/reduce-max-1>`
* :doc:`ReduceMean <../operation-specs/reduction/reduce-mean-1>`
* :doc:`ReduceMin <../operation-specs/reduction/reduce-min-1>`
* :doc:`ReduceProd <../operation-specs/reduction/reduce-prod-1>`
* :doc:`ReduceSum <../operation-specs/reduction/reduce-sum-1>`
* :doc:`RegionYolo <../operation-specs/detection/region-yolo-1>`
* :doc:`ReorgYolo <../operation-specs/detection/reorg-yolo-1>`
* :doc:`Reshape <../operation-specs/shape/reshape-1>`
* :doc:`Result <../operation-specs/infrastructure/result-1>`
* :doc:`ReverseSequence <../operation-specs/movement/reverse-sequence-1>`
* :doc:`RNNCell <../operation-specs/sequence/rnn-cell-3>`
* :doc:`RNNSequence <../operation-specs/sequence/rnn-sequence-5>`
* :doc:`ROIAlign <../operation-specs/detection/roi-align-9>`
* :doc:`ROIPooling <../operation-specs/detection/roi-pooling-1>`
* :doc:`Roll <../operation-specs/movement/roll-7>`
* :doc:`Round <../operation-specs/arithmetic/round-5>`
* :doc:`ScatterElementsUpdate <../operation-specs/movement/scatter-elements-update-3>`
* :doc:`ScatterNDUpdate <../operation-specs/movement/scatter-nd-update-3>`
* :doc:`ScatterUpdate <../operation-specs/movement/scatter-update-3>`
* :doc:`Select <../operation-specs/condition/select-1>`
* :doc:`Selu <../operation-specs/activation/selu-1>`
* :doc:`ShapeOf <../operation-specs/shape/shape-of-3>`
* :doc:`ShuffleChannels <../operation-specs/movement/shuffle-channels-1>`
* :doc:`Sigmoid <../operation-specs/activation/sigmoid-1>`
* :doc:`Sign <../operation-specs/arithmetic/sign-1>`
* :doc:`Sin <../operation-specs/arithmetic/sin-1>`
* :doc:`Sinh <../operation-specs/arithmetic/sinh-1>`
* :doc:`Slice <../operation-specs/movement/slice-8>`
* :doc:`SoftMax <../operation-specs/activation/softmax-8>`
* :doc:`SoftPlus <../operation-specs/activation/softplus-4>`
* :doc:`SoftSign <../operation-specs/activation/softsign-9>`
* :doc:`SpaceToBatch <../operation-specs/movement/space-to-batch-2>`
* :doc:`SpaceToDepth <../operation-specs/movement/space-to-depth-1>`
* :doc:`Split <../operation-specs/movement/split-1>`
* :doc:`Sqrt <../operation-specs/arithmetic/sqrt-1>`
* :doc:`SquaredDifference <../operation-specs/arithmetic/squared-difference-1>`
* :doc:`Squeeze <../operation-specs/shape/squeeze-1>`
* :doc:`StridedSlice <../operation-specs/movement/strided-slice-1>`
* :doc:`Subtract <../operation-specs/arithmetic/subtract-1>`
* :doc:`Swish <../operation-specs/activation/swish-4>`
* :doc:`Tan <../operation-specs/arithmetic/tan-1>`
* :doc:`Tanh <../operation-specs/arithmetic/tanh-1>`
* :doc:`TensorIterator <../operation-specs/infrastructure/tensor-iterator-1>`
* :doc:`Tile <../operation-specs/movement/tile-1>`
* :doc:`TopK <../operation-specs/sort/top-k-3>`
* :doc:`Transpose <../operation-specs/movement/transpose-1>`
* :doc:`Unsqueeze <../operation-specs/shape/unsqueeze-1>`
* :doc:`VariadicSplit <../operation-specs/movement/variadic-split-1>`

