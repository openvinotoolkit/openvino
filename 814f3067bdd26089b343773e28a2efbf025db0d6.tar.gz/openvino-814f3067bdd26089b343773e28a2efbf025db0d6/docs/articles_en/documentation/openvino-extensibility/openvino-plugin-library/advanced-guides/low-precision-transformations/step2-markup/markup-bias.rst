.. {#openvino_docs_OV_UG_lpt_MarkupBias}

MarkupBias transformation
=========================

ov::pass::low_precision::MarkupBias class represents the `MarkupBias` transformation.
