.. {#openvino_docs_OV_UG_lpt_ShuffleChannelsTransformation}

ShuffleChannelsTransformation transformation
============================================

ov::pass::low_precision::ShuffleChannelsTransformation class represents the `ShuffleChannels` operation transformation.
