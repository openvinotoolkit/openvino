.. {#openvino_docs_OV_UG_lpt_FakeQuantizeTransformation}

FakeQuantizeTransformation transformation
=========================================

ov::pass::low_precision::FakeQuantizeTransformation class represents the `FakeQuantize` operation transformation.
