.. {#openvino_docs_OV_UG_lpt_FakeQuantizeDecompositionTransformation}

FakeQuantizeDecompositionTransformation transformation
======================================================

ov::pass::low_precision::FakeQuantizeDecompositionTransformation class represents the `FakeQuantizeDecompositionTransformation` transformation.
