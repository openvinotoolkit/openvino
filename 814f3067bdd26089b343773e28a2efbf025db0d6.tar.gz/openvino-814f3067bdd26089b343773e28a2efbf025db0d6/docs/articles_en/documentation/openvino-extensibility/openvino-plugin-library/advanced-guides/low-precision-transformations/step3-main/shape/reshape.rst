.. {#openvino_docs_OV_UG_lpt_ReshapeTransformation}

ReshapeTransformation transformation
====================================

ov::pass::low_precision::ReshapeTransformation class represents the `Reshape` operation transformation.
