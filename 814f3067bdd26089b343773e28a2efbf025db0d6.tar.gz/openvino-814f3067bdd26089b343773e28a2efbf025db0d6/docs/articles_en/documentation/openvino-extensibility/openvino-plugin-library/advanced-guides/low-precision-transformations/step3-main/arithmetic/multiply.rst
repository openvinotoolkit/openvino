.. {#openvino_docs_OV_UG_lpt_MultiplyTransformation}

MultiplyTransformation transformation
=====================================

ov::pass::low_precision::MultiplyTransformation class represents the `Multiply` operation transformation.