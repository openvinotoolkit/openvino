.. {#openvino_docs_OV_UG_lpt_MultiplyToGroupConvolutionTransformation}

MultiplyToGroupConvolutionTransformation transformation
=======================================================

ov::pass::low_precision::MultiplyToGroupConvolutionTransformation class represents the `MultiplyToGroupConvolutionTransformation` transformation.
