.. {#openvino_docs_OV_UG_lpt_PropagateSharedValue}

PropagateSharedValue transformation
===================================

ov::pass::low_precision::PropagateSharedValue class represents the `PropagateSharedValue` transformation.
