.. {#openvino_docs_OV_UG_lpt_AlignQuantizationIntervals}

AlignQuantizationIntervals transformation
=========================================

ov::pass::low_precision::AlignQuantizationIntervals class represents the `AlignQuantizationIntervals` transformation.
