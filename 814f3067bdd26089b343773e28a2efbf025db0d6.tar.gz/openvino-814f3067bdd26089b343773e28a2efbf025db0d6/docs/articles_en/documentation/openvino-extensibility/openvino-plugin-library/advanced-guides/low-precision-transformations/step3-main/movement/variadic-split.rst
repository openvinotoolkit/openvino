.. {#openvino_docs_OV_UG_lpt_VariadicSplitTransformation}

VariadicSplitTransformation transformation
==========================================

ov::pass::low_precision::VariadicSplitTransformation class represents the `VariadicSplit` operation transformation.
