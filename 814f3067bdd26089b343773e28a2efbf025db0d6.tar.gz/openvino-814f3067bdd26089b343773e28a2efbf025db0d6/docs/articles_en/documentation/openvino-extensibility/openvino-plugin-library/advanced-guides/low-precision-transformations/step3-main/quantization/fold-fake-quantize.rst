.. {#openvino_docs_OV_UG_lpt_FoldFakeQuantizeTransformation}

FoldFakeQuantizeTransformation transformation
=============================================

ov::pass::low_precision::FoldFakeQuantizeTransformation class represents the `FoldFakeQuantize` operation transformation.
