.. {#openvino_docs_OV_UG_lpt_MarkupCanBeQuantized}

MarkupCanBeQuantized transformation
===================================

ov::pass::low_precision::MarkupCanBeQuantized class represents the `MarkupCanBeQuantized` transformation.
