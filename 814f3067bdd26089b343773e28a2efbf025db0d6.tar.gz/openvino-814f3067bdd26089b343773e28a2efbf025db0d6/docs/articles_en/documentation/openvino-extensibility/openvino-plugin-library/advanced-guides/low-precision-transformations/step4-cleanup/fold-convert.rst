.. {#openvino_docs_OV_UG_lpt_FoldConvertTransformation}

FoldConvertTransformation transformation
========================================

ov::pass::low_precision::FoldConvertTransformation class represents the `FoldConvertTransformation` transformation.
