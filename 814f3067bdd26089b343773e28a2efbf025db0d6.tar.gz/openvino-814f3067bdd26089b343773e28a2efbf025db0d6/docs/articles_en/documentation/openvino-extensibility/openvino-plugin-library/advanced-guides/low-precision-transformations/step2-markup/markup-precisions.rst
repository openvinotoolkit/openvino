.. {#openvino_docs_OV_UG_lpt_MarkupPrecisions}

MarkupPrecisions transformation
===============================

ov::pass::low_precision::MarkupPrecisions class represents the `MarkupPrecisions` transformation.
