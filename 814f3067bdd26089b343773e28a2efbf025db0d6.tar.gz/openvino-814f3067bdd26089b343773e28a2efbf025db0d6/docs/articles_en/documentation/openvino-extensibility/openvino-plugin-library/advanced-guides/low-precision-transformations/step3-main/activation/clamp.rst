.. {#openvino_docs_OV_UG_lpt_ClampTransformation}

ClampTransformation transformation
==================================

ov::pass::low_precision::ClampTransformation class represents the `Clamp` operation transformation.
