.. {#openvino_docs_OV_UG_lpt_SpaceToBatchTransformation}

SpaceToBatchTransformation transformation
=========================================

``ov::pass::low_precision::SpaceToBatchTransformation`` class represents the ``SpaceToBatch`` operation transformation.
