.. {#openvino_docs_OV_UG_lpt_AvgPoolTransformation}

AvgPoolTransformation transformation
====================================

ov::pass::low_precision::AvgPoolTransformation class represents the `AvgPool` operation transformation.
