.. {#openvino_docs_OV_UG_lpt_UnsqueezeTransformation}

UnsqueezeTransformation transformation
======================================

ov::pass::low_precision::UnsqueezeTransformation class represents the `Unsqueeze` operation transformation.
