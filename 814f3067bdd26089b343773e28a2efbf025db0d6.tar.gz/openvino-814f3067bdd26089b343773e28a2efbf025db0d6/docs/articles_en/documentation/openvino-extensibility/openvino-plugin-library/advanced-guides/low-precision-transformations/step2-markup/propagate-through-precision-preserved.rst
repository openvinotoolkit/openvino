.. {#openvino_docs_OV_UG_lpt_PropagateThroughPrecisionPreserved}

PropagateThroughPrecisionPreserved transformation
=================================================

ov::pass::low_precision::PropagateThroughPrecisionPreserved class represents the `PropagateThroughPrecisionPreserved` transformation.
