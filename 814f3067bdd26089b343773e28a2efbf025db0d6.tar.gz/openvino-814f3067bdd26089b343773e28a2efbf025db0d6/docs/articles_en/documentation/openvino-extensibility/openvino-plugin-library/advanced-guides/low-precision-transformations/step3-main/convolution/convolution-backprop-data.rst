.. {#openvino_docs_OV_UG_lpt_ConvolutionBackpropDataTransformation}

ConvolutionBackpropDataTransformation transformation
====================================================

ov::pass::low_precision::ConvolutionBackpropDataTransformation class represents the `ConvolutionBackpropData` operation transformation.
