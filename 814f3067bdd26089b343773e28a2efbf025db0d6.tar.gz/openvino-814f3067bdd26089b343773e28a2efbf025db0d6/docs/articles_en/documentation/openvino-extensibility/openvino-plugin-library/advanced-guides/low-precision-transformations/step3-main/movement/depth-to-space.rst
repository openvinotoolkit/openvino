.. {#openvino_docs_OV_UG_lpt_DepthToSpaceTransformation}

DepthToSpaceTransformation transformation
=========================================

ov::pass::low_precision::DepthToSpaceTransformation class represents the `DepthToSpace` operation transformation.
