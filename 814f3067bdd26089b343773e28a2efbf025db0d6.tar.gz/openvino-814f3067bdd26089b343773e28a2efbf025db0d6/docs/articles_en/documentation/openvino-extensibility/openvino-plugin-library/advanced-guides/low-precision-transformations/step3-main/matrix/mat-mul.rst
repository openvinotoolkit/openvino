.. {#openvino_docs_OV_UG_lpt_MatMulTransformation}

MatMulTransformation transformation
===================================

ov::pass::low_precision::MatMulTransformation class represents the `MatMul` operation transformation.
