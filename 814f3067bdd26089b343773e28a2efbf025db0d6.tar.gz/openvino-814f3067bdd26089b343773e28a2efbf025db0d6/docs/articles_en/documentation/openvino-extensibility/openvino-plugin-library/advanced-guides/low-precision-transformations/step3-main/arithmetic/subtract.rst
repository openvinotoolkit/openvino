.. {#openvino_docs_OV_UG_lpt_SubtractTransformation}

SubtractTransformation transformation
=====================================

ov::pass::low_precision::SubtractTransformation class represents the `Subtract` operation transformation.