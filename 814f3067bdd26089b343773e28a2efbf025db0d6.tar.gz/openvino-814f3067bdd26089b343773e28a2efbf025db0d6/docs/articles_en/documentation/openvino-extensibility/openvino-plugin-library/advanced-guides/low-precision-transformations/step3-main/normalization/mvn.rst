.. {#openvino_docs_OV_UG_lpt_MVNTransformation}

MVNTransformation transformation
================================

ov::pass::low_precision::MVNTransformation class represents the `MVN` operation transformation.
