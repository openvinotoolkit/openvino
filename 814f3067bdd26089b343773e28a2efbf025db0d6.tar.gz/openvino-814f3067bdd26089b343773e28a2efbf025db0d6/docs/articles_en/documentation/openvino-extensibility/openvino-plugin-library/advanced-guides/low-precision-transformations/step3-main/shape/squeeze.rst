.. {#openvino_docs_OV_UG_lpt_SqueezeTransformation}

SqueezeTransformation transformation
====================================

ov::pass::low_precision::SqueezeTransformation class represents the `Squeeze` operation transformation.
