.. {#openvino_docs_OV_UG_lpt_ReduceSumTransformation}

ReduceSumTransformation transformation
======================================

ov::pass::low_precision::ReduceSumTransformation class represents the `ReduceSum` operation transformation.
