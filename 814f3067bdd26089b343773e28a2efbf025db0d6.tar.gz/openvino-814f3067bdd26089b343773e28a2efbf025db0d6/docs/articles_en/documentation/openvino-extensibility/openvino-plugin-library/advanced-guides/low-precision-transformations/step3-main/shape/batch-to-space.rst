.. {#openvino_docs_OV_UG_lpt_BatchToSpaceTransformation}

BatchToSpaceTransformation transformation
=========================================

``ov::pass::low_precision::BatchToSpaceTransformation`` class represents the ``BatchToSpace`` operation transformation.
