.. {#openvino_docs_OV_UG_lpt_UpdateSharedPrecisionPreserved}

UpdateSharedPrecisionPreserved transformation
=============================================

ov::pass::low_precision::UpdateSharedPrecisionPreserved class represents the `UpdateSharedPrecisionPreserved` transformation.
