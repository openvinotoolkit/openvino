.. {#openvino_docs_OV_UG_lpt_LinOpSequenceFusion}

LinOpSequenceFusion transformation
==================================

``ov::pass::LinOpSequenceFusion`` class represents the ``LinOpSequenceFusion`` transformation.

``LinOpSequenceFusion`` is a common OpenVINO transformation.
