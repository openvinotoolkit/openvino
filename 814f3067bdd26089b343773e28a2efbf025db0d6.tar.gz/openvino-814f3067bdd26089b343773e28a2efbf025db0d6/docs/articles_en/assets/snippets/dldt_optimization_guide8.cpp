int main() {
//! [part8]
while(true) {
    // capture frame
    // populate CURRENT InferRequest
    // Infer CURRENT InferRequest //this call is synchronous
    // display CURRENT result
}
//! [part8]
return 0;
}
